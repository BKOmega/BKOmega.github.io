---
title: Bits & Bytes
nav_order: 1
---

Welcome! This is my living, anonymised record of a real home lab:

- **Diary** for what changed
- **Guides** you can follow end-to-end
- **Runbooks** for fast fixes
- **Designs** that explain the “why”
- **Templates** you can copy‑paste

Start with the **[Inventory](/inventory/)**.
